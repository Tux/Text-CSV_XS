#!/usr/bin/perl

use v5.36;
use Text::CSV_XS 1.51 qw(csv);
use utf8;
use DDumper;

# Test input is CRLF.
open( my $fh, '<', shift ) or die;

my $res;
# 1st CSV: Groups
$res = csv( in => $fh,
	    skip_empty_rows => 2, # stop
	    binary => 1,
	    headers => "auto" );
DDumper($res);

warn("POS: ", $fh->tell, "\n");
$res = csv( in => $fh,
	    skip_empty_rows => 2, # stop
	    binary => 1,
	    headers => "auto" );
DDumper($res);
